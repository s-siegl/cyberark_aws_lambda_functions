#
#
#
#
# This code is provided as sample lambda function to automate new AWS instances provisionning in CyberArk.
# Warning: This is not a production code.
# The Lambda function should be trigred by a pending state CloudWatch event.
#
# Please update the global variables consequently with your configuration.
#
# 
#

# Used libraries import
import boto3
import requests
import tempfile
import json
import os
from random import randint
from requests.packages.urllib3.exceptions import InsecureRequestWarning


# remove me: ignore SSL errors 
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


###################### GLOBAL Variables to be updated ##########################
# AWS tags global variables
applicationid_tag = 'ApplicationID' # this tag is used to create safe in CyberArk
owner_tag = 'Owner' # this tag is used to position the owner of the safe 

# CybeArk Vault REST API account details
rest_acc_safe = 'CyberArkWebServicesAccounts' # safe where the Vault REST API connection account is stored
rest_acc_obj = 'CyberArkWebServiceAccount' # name of the Vault REST API connection account object 

# CyberArk Central Crentials connection params
cc_host = '35.156.156.136' # IP or DNS name of the central credential provider
cc_appid = 'RestApp' # CyberArk Applciation ID used to retrieve the Vault REST API connection account
certificate = '-----BEGIN CERTIFICATE-----\nMIIHQTCCBSmgAwIBAgITJgAAABwcCvdCebpIuwAAAAAAHDANBgkqhkiG9w0BAQsF\nADA9MRMwEQYKCZImiZPyLGQBGRYDbGFuMRQwEgYKCZImiZPyLGQBGRYEZGVtbzEQ\nMA4GA1UEAxMHZGVtby1DQTAeFw0xNTA4MjAwODQyMjJaFw0xNzA4MjAwODUyMjJa\nMIGWMQswCQYDVQQGEwJGUjEOMAwGA1UECBMFUGFyaXMxEzARBgNVBAcTCkxhIERl\nZmVuc2UxETAPBgNVBAoTCEN5YmVyQXJrMRwwGgYDVQQLExNDeWJlckFya0FJTVBy\nb3ZpZGVyMRAwDgYDVQQDEwdTb2FwQXBwMR8wHQYJKoZIhvcNAQkBFhBkamFtZWxi\nQGRlbW8ubGFuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAszEY23vm\nmzhu6fK3BC3LoDBRKoGx+mq4eb7TM46IOnzksdsMxuOWLxZl4vikBmZLAD4TLDGc\nk+p2hctjXRSpsJ+0xcnb5Y4nZehhyuYm12F7+ROQfSE81jSxmcoe7KvRImk48L4Y\nJK6qV14WeayQTZm1lEZh3Dl2sIR1HwO3R7aCI3C+1LYWumicJR8tcvfHmOmsrv0z\n8kgX6uvMbyoz8kNd3sFO6fTCRvD0QU1KUN3xn+SUppRaFya2rR12RTgxPn5bdg1T\ntTJbOi6Ci5ObnMzbyFIB9wz/8YNphnwu//53U97iV7f/TIsDl0WSTcH0FbRFBW/B\nocIxVhsXNbuqYwIDAQABo4IC3jCCAtowDgYDVR0PAQH/BAQDAgSwMDsGCSsGAQQB\ngjcVBwQuMCwGJCsGAQQBgjcVCKa+BITEmX/xjyaF9Ksdgf22LCKBz7JshrWgbwIB\nZAIBBTBEBgkqhkiG9w0BCQ8ENzA1MA4GCCqGSIb3DQMCAgIAgDAOBggqhkiG9w0D\nBAICAIAwBwYFKw4DAgcwCgYIKoZIhvcNAwcwHQYDVR0OBBYEFKprdFqHHwt0pdGo\n5ft+v86dLQK9MB8GA1UdIwQYMBaAFOU4CoS/1aRbj5MVpWn4OGqNqMYPMIIBAgYD\nVR0fBIH6MIH3MIH0oIHxoIHuhoGzbGRhcDovLy9DTj1kZW1vLUNBLENOPVdJTi1B\nODk1TU83SUtJUCxDTj1DRFAsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049\nU2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1kZW1vLERDPWxhbj9jZXJ0aWZp\nY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Q2xhc3M9Y1JMRGlzdHJpYnV0\naW9uUG9pbnSGNmh0dHA6Ly9XSU4tQTg5NU1PN0lLSVAuZGVtby5sYW4vQ2VydEVu\ncm9sbC9kZW1vLUNBLmNybDCBtgYIKwYBBQUHAQEEgakwgaYwgaMGCCsGAQUFBzAC\nhoGWbGRhcDovLy9DTj1kZW1vLUNBLENOPUFJQSxDTj1QdWJsaWMlMjBLZXklMjBT\nZXJ2aWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWRlbW8sREM9\nbGFuP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u\nQXV0aG9yaXR5MB0GA1UdJQQWMBQGCCsGAQUFBwMCBggrBgEFBQcDATAnBgkrBgEE\nAYI3FQoEGjAYMAoGCCsGAQUFBwMCMAoGCCsGAQUFBwMBMA0GCSqGSIb3DQEBCwUA\nA4ICAQAN+qz/aU/QRKZwnJn1FvOYMe9qfkHfFL0laseiV1edI2PwaNJJVOIPdoMo\nubBKOLG4HFKRiQEYGDAud9SpjU3YAtEVLqu3c1i2yKGXlW/Byri6ZU2V8bvVpDfT\n3Rxf4XTaOQPPpV0SvqxxGnuSimBRmfGdx+fJhsLAheQgrAAOvgfleJtVxUGoX24r\nEw1OtO0/IbD6SXAbAqTLS9dcTDjfLLiux3Nrre5U/ZqoL7z1B6sEhdK+2KYnyxhP\n9UoxMdE2yXXTnHK05ZoG+TgOt4pYVTmAmfhfyHvM7meOMVFUNQfjMIkZSIrJdGU+\n1ZGv8ziv+x+j2HlQrg59B6nrQbnmMABqYccWCGc3WeHshRCTIY5JrAFgRHEX2cS0\nzXTLwGOjFiolY1JT8eXWuFgYyUyYZ751ixStbBVUyqDw0F/spNWdFHn5/8Gul7HX\nNG1boMvPdDw9/aDaNIdiQMp+JpITVVkLCknHmEHE9TCq/FhiO5f+oRkfNEhnfUl1\nfADRh/CWYRWPIuRtu+5PLf0reQvCUrxxJ490h3X4BGTvkgQTJrABLLexaVvRd8Kq\nDghLfk9LKh9QM4OZvdZKywkDevNuof0/YRcLYp8j0BaNVFfDDBCR24aFWx6kVQlI\nsMUVUx0H+6YQV0fUMtqV8WE5gJIAUjzCBjdoW/UEbaRB1DSrZA==\n-----END CERTIFICATE-----\n'
cacert = '-----BEGIN CERTIFICATE-----\r\nMIIFVTCCAz2gAwIBAgIQXk97Et1NDJFH6KhX8KuYLTANBgkqhkiG9w0BAQsFADA9\r\nMRMwEQYKCZImiZPyLGQBGRYDbGFuMRQwEgYKCZImiZPyLGQBGRYEZGVtbzEQMA4G\r\nA1UEAxMHZGVtby1DQTAeFw0xNTA4MDYxMDQ1MDdaFw0yMDA4MDYxMDU1MDZaMD0x\r\nEzARBgoJkiaJk/IsZAEZFgNsYW4xFDASBgoJkiaJk/IsZAEZFgRkZW1vMRAwDgYD\r\nVQQDEwdkZW1vLUNBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAsA3d\r\nbUkx4NiTdjQrqDmVJd5VOAxOsrH0dwskPhQkJESZC/6QCuuoxBLl0KKrtw5IZkV8\r\n+uvtqfsH6XYTLIzwqiY4oVaIFlrEmnners4hP+NSBipBKDOt7klqwdC8iFUD2w/X\r\nN75KRYtkxqszVGE41BApd48HLl9B8NohZQokjGw2ltolWAyb3ssGAs01TcMqCHCu\r\nPeZIWInc1x8K+ZLF1zA05cH7eUvvN3M2cQtnwAr9qdHoRorxCxJ7URndLGUG7oME\r\n3r+eGxBlGAeN/o1hBnknLh4m6fZ/HIs17keoaJOd7Aw8FzwUUsGRScc7MGc4OcDL\r\nO/FzIWwf8UHjeW5UgyA0rlPiuy3CTVd7+yDfIByBsfdq+mTBfWIjDGp17v/5jpVs\r\nylfWZt5DyTTuIcWOh/Z+LQNwQbZkehM6h1/jp+UYiuj5xBkUG7ron4essTHC+Pit\r\nyw4VmYVlsq0ZKA990+ss9WBiVUrjXH32qv58TGwKgKAc4FsvuAATnCSW2zI9zYBf\r\nH16/NLA6PmnxjYln8f1VrO3EI5xtAW30TPu0CQUnh5MgUo2JaTRdSNK7srpCaSXw\r\nlNLo23ZCUbJQAVZ5I+BitOK3w/LqHU//LcDHbRyRimbreOn013uxpooHBbLo4Qmu\r\nBf/PHBv8XLBWEi6xfERE/a+oCJwLR8rOww5rGp0CAwEAAaNRME8wCwYDVR0PBAQD\r\nAgGGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFOU4CoS/1aRbj5MVpWn4OGqN\r\nqMYPMBAGCSsGAQQBgjcVAQQDAgEAMA0GCSqGSIb3DQEBCwUAA4ICAQA5HVoYJrYQ\r\nsInvwI/j7HlaXZwvqvZOuqHwL8rmOPWjAsfgPvht83F0rIk5cc4Iqpyim7fS29OV\r\n+mElYkLxfq/ATtkDv2dxHJqlIWKRCXmgGEAMRHl+nZh8z1DKATg0rEl8+MfM3wIh\r\nvJNbkl/P7AhaSbt9C8kYJQBnrnBBWQs0xzSYE6RapwsfabY1e7mauknSfFswcdb2\r\nanTIiHTs1Q9E8NqHAJ/qUrDzZHbqlZ0mW9B38gJ5CaWPYHJaIIo7nzmX7F4/L/Yo\r\n4sd8rQjINfywSg0uB1PS1WlYtM6p0xCc+9m8bT5Ik1z6C98E4JRmbqGApLbkz7+g\r\nszI20wF/4OB/QRw5us5s/hNRJtEF3tk+vhgRi+cCrKausH6cSIFuSTegqJI0iTXF\r\nXP3fSTf8PPWysSEqCTbAwx0abTDEwpIT/m34rrTeEPl1cQSckmggArpVmut6sV4a\r\nu4RjA4FOkk6urmEqlReM94f3fA+KuAER6fAbwsvyU/zWEo2BiisMAfdbL+uzhfx3\r\nadCCq18OUzrh9UmA3/R8v4F/d658lkPGo5INN0K4UoR3LmW/p9e6uqrvQZr6nCU1\r\nrglCUoWlHdx/RXjqjy/atCSfcg5TqjqQZB9FZ2YLASO/bWJnQ6/M1x/7yFxBpr8R\r\n2s1SL9PeprUgLBFe7hpOgfsdpfzElmiS3w==\r\n-----END CERTIFICATE-----\r\n-----BEGIN CERTIFICATE-----\r\nMIIGljCCBH6gAwIBAgITJgAAAEJDBWnCSUELGAAAAAAAQjANBgkqhkiG9w0BAQsF\r\nADA9MRMwEQYKCZImiZPyLGQBGRYDbGFuMRQwEgYKCZImiZPyLGQBGRYEZGVtbzEQ\r\nMA4GA1UEAxMHZGVtby1DQTAeFw0xNTEwMjgxMTEwMjFaFw0xNzEwMjgxMTIwMjFa\r\nMCMxITAfBgNVBAMTGFdJTi04TTk0UkVBOE82Ni5kZW1vLmxhbjCCASIwDQYJKoZI\r\nhvcNAQEBBQADggEPADCCAQoCggEBAKZgv6CV3cIQjrdaQIQwm6jEtUfFgd5Scadd\r\nL/NlNZe8e0e7u83zxfLbxgBG2NON/SeTL15WjycZjFXMHMQm7MczYLSGR2UlMB89\r\nIDybgDi2DAc5eWVjA44JFp/+FYuvJaIHqkwUN+q8Mc08njSxmVooU1UzHDNEKOHZ\r\nZhtDZg09Y1Ut6PPklMJRXz4ps2i39OWsvR4qzvi3CoN3NfGy/bSeJ+OXljuPfdrD\r\nEmvg8Zw4Ep1meEVsJQ1B6Jy9sWIfHHwgfjnQ1yi5zIDx4UEEV6zD3P7rAj0GcSYm\r\nECz4K9uuhyXLhWDDKpKK1JtrhKVbnaOjcO7C5xG6hE2w/DluSs8CAwEAAaOCAqcw\r\nggKjMDsGCSsGAQQBgjcVBwQuMCwGJCsGAQQBgjcVCKa+BITEmX/xjyaF9Ksdgf22\r\nLCKFmfVjhdHlOwIBZAIBBzATBgNVHSUEDDAKBggrBgEFBQcDATAOBgNVHQ8BAf8E\r\nBAMCBLAwGwYJKwYBBAGCNxUKBA4wDDAKBggrBgEFBQcDATAdBgNVHQ4EFgQUOQk6\r\nnztjCnrMgr0FeWCOlIdbSWMwHwYDVR0jBBgwFoAU5TgKhL/VpFuPkxWlafg4ao2o\r\nxg8wggECBgNVHR8EgfowgfcwgfSggfGgge6GgbNsZGFwOi8vL0NOPWRlbW8tQ0Es\r\nQ049V0lOLUE4OTVNTzdJS0lQLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2\r\naWNlcyxDTj1TZXJ2aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPWRlbW8sREM9bGFu\r\nP2NlcnRpZmljYXRlUmV2b2NhdGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxE\r\naXN0cmlidXRpb25Qb2ludIY2aHR0cDovL1dJTi1BODk1TU83SUtJUC5kZW1vLmxh\r\nbi9DZXJ0RW5yb2xsL2RlbW8tQ0EuY3JsMIG2BggrBgEFBQcBAQSBqTCBpjCBowYI\r\nKwYBBQUHMAKGgZZsZGFwOi8vL0NOPWRlbW8tQ0EsQ049QUlBLENOPVB1YmxpYyUy\r\nMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24sREM9\r\nZGVtbyxEQz1sYW4/Y0FDZXJ0aWZpY2F0ZT9iYXNlP29iamVjdENsYXNzPWNlcnRp\r\nZmljYXRpb25BdXRob3JpdHkwIwYDVR0RBBwwGoIYV0lOLThNOTRSRUE4TzY2LmRl\r\nbW8ubGFuMA0GCSqGSIb3DQEBCwUAA4ICAQCc9Es4FOSSn1f0KLqhSctkuuhuGyyF\r\nxUE8wKh5cvwSa1szIxPojk9fOWgPbLmJzI0ikSpnIIWZO8A++ZaXWN9c0xy/3mdx\r\nrJh/NxfSD8tsbBI40R5VLrNNdpzLHmZ07zgAMoa/XPurUNlSlcwc63JrWucocRIa\r\nHnjoYAp7sHpIDefvq+U4EaVChh2yVypoKzhLhr3IWbwl/BBczkyjuH1la8nw9Mf7\r\nakB/sopxi7tY18wYAIp5lIUufdJ0rZJdg3hKFgoQAFCEkMWkWpgtqVuzOrXTjasy\r\ne9I920gZs2voG4odlf6LnpK4tplE+8o3H7sCpSw8PZ3n/1momZC6MJWKAX60dbtY\r\naTC1YZgr+w/qKYJRm2RKoFOoYOy++6+i4YWl+U6kLQHKxqrrz3IxTAcTfdMSveGh\r\nxw4HzQRVCe2whSFnjElJRi+M4iHrYERQv3bDpGLvrA+ve/ycEnc68A4eIyUqtQeW\r\nJM9+ni4TVJC7JpcaxHKynHNJ0/MKmjE1jozh4/vE6D9myTDLfVHe4s6d8abeiXIz\r\n5dY/uTWo93w/0KLT4iWxp6aO9I3/TmHw+bg8vEFc3zBejyezHeFTyPBar8Nf0pv2\r\nOUFb0bEFTTl1/l3yyBtWBePwKvOMZBXjIJHIVGfRrsO9lwvwkSP78vDhR/vrmWFG\r\nk1LIauyyyoyuxg==\r\n-----END CERTIFICATE-----\r\n'

# CyberArk REST API connection params
rest_host = '35.156.156.136' # IP or DNS name of CyberArk REST API 

# Default provisionning parameters
default_safe='Test'
default_owner='Administrator'

################################################################################

# Function to retrieve newly created AWS VM information
def get_vm_props(instanceid):
    ec2 = boto3.resource('ec2')
    instance = ec2.Instance(instanceid)
    vm_data = {'dns': instance.private_dns_name, 'ip': instance.private_ip_address, 'platform': instance.platform, 'owner': '', 'applicationid': '', 'name': ''}
    for tags in instance.tags:
        if 'Name'in tags['Key']:
            vm_data['name'] = tags['Value']
        if applicationid_tag in tags['Key']:
            vm_data['applicationid'] = tags['Value']
        if owner_tag in tags['Key']:
            vm_data['owner'] = tags['Value']
    return vm_data
    
# Function to retrieve credentials used to authenticate to CyberArk Vault REST API
def get_cybr_api_cred(host, appid, safe, obj):
    json_response_data=''
    head = {"Content-type": "application/json"}
    url = 'https://' + host +'/AIMWebService/api/Accounts?AppID=' + appid + '&Safe=' + safe + '&Object=' + obj
    # Write Keys and certificate to temp file removed after connection made
    with tempfile.NamedTemporaryFile(suffix='.pem') as cert_pem:
        fcert_pem = open(cert_pem.name, 'w')
        private_key = os.environ['PrivateKey'].replace("\\n", "\n")
        fcert_pem.write(certificate)
        fcert_pem.write(private_key)
        fcert_pem.flush()
        with tempfile.NamedTemporaryFile(suffix='.pem') as cacert_pem:
                fcacert_pem = open(cacert_pem.name, 'w')
                fcacert_pem.write(cacert)
                fcacert_pem.flush()
                #changeme to point the certificate chain
                ret = requests.get(url, headers=head, cert=cert_pem.name, timeout=30, verify=False)
                if ret.status_code != 200:
                    raise Exception("Error occured during get_cybr_api_cred call. CyberArk error:",ret.content)
                json_response_data = json.loads(ret.content)
                fcacert_pem.close()
        fcert_pem.close()
    return json_response_data

# Function to login to CyberArk Vault REST API
def login_cybr_api(username, password):
    url = 'https://' + rest_host + '/PasswordVault/WebServices/auth/cyberark/CyberArkAuthenticationService.svc/logon'
    json_response_data=''
    json_request_data={"username":username,"password":password,"connectionNumber":randint(1,100)}
    head = {"Content-type": "application/json"}
    ret = requests.post(url, headers=head, data=json.dumps(json_request_data), timeout=30, verify=False)
    if ret.status_code != 200:
        raise Exception("Error occured during login_cybr_api call. CyberArk error:",ret.content)
    json_response_data = json.loads(ret.content)
    return json_response_data['CyberArkLogonResult']

# Function to logoff from CyberArk Vault REST API
def logoff_cybr_api(auth_string):
    url = 'https://' + rest_host + '/PasswordVault/WebServices/auth/cyberark/CyberArkAuthenticationService.svc/logoff'
    head = {"Content-type": "application/json","Authorization":auth_string}
    ret = requests.post(url, headers=head, timeout=30, verify=False)
    if ret.status_code != 200:
        raise Exception("Error occured during logoff_cybr_api call. CyberArk error:",ret.content)
    return

# Function to search a safe
def search_safe(auth_string,safe):
    url = 'https://' + rest_host + '/PasswordVault/WebServices/PIMServices.svc/Safes?query=' + safe
    json_response_data=''
    head = {"Content-type": "application/json","Authorization":auth_string}
    ret = requests.get(url, headers=head, timeout=30, verify=False)
    if ret.status_code != 200:
        logoff_cybr_api(auth_string)
        raise Exception("Error occured during search_safe call. CyberArk error:",ret.content)
    json_response_data = json.loads(ret.content)
    if not json_response_data['SearchSafesResult']:
        return False
    return True
    
# Function to delete account 
def delete_account(auth_string,accountid):
    url = 'https://' + rest_host + '/PasswordVault/WebServices/PIMServices.svc/Accounts/' + accountid 
    head = {"Content-type": "application/json","Authorization":auth_string}
    ret = requests.delete(url, headers=head, timeout=30, verify=False)
    if ret.status_code != 200:
        logoff_cybr_api(auth_string)
        raise Exception("Error occured during delete_account call. CyberArk error:",ret.content)
    return 

# Function to delete safe 
def delete_safe(auth_string,safe):
    url = 'https://' + rest_host + '/PasswordVault/WebServices/PIMServices.svc/Safes/' + safe 
    head = {"Content-type": "application/json","Authorization":auth_string}
    ret = requests.delete(url, headers=head, timeout=30, verify=False)
    if ret.status_code != 200:
        logoff_cybr_api(auth_string)
        raise Exception("Error occured during delete_safe call. CyberArk error:",ret.content)
    return 

# Function to search an account and return its ID
def search_account(auth_string,account,all_safes=True,only_safe=False):
    if only_safe == False:
        url = 'https://' + rest_host + '/PasswordVault/WebServices/PIMServices.svc/Accounts?Keywords=' + account['instanceid'] + "&Safe="
    else:
        url = 'https://' + rest_host + '/PasswordVault/WebServices/PIMServices.svc/Accounts?Keywords=' + "&Safe="
    if all_safes == False:
        url += account['safe'] 
    json_response_data=''
    head = {"Content-type": "application/json","Authorization":auth_string}
    ret = requests.get(url, headers=head, timeout=30, verify=False)
    if ret.status_code != 200:
        logoff_cybr_api(auth_string)
        raise Exception("Error occured during search_account call. CyberArk error:",ret.content)
    json_response_data = json.loads(ret.content)
    return json_response_data

# AWS Lambda function handler
def lambda_handler(event, context):
    # Get VM properties
    vm_props = get_vm_props(event['detail']['instance-id'])
    # Check if Safe parameter is defined
    safe=''
    if vm_props['applicationid']!='':
        safe=vm_props['applicationid']
    elif default_safe!='':
        safe=default_safe
    else:
        return 'No Safe parameter found in VM tag and no default safe defined'
    # Check if Owner parameter is defined
    owner=''
    if vm_props['owner']!='':
        owner=vm_props['owner']
    elif default_owner!='':
        owner=default_owner
    else:
        return 'No Owner parameter found in VM tag and no default owner defined'
    # Get Vault Rest API credentials
    cred_api = get_cybr_api_cred(cc_host, cc_appid, rest_acc_safe, rest_acc_obj)
    # Login to CyberArk REST API
    auth_string = login_cybr_api(cred_api['UserName'],cred_api['Content'])
	# Define account properties
    formated_safe_name = safe.replace(" ", "%20")
    account = {'username': '', 'address': vm_props['ip'], 'safe': formated_safe_name, 'instanceid': event['detail']['instance-id']}
    # Search if account exists
    found_account = search_account(auth_string,account)
    i = 0
    accounts_num = found_account['Count']
    while i < accounts_num: 
        for item in found_account["accounts"]:
            accountid = item["AccountID"]
            # Delete account
            delete_account(auth_string,accountid)
            found_account = search_account(auth_string,account)
        i += 1
    # Look if safe is empty and if so delete it: This code is commented. You need to take care of the retention period
    #found_account = search_account(auth_string,account,False,True)
    #accounts_num = found_account['Count']
    #if accounts_num == 0:
    #    delete_safe(auth_string,formated_safe_name)
    # Logoff from CyberArk API
    logoff_cybr_api(auth_string)
    return 'function ended successfully'
